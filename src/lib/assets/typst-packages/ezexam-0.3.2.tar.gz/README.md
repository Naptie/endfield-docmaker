# ezexam

![Typst Version](https://img.shields.io/badge/dynamic/toml?url=https%3A%2F%2Fraw.githubusercontent.com%2Fgbchu%2Fezexam%2Frefs%2Fheads%2Fmain%2Ftypst.toml&query=%24.package.version&prefix=v&logo=typst&label=package&color=239DAD)
[![Online Documentation](https://img.shields.io/badge/docs-online-007aff)](https://ezexam.pages.dev/)


This template can help Chinese university, primary, middle and high school teachers or students in creating exam or handouts.

## Example
```typst
#import "@preview/ezexam:0.3.2": *
#show: setup.with(
  mode: EXAM,
  paper: a3
)

#title[xx期末考试]

= 选择
#question[
  $(1 + 5"i")"i"$ 的虚部为 #paren[]
  #choices(-1, 0, 1, 6)
]

......

= 填空
#question[
  一个箱子里有 5 个球，分别以 1$~$5 标号，若有放回取三次，记至少取出一次的球的个数 $X$，则 $E(X) =$#fillin[].
]

......

= 解答题
#question(points: 15)[
  设数列 ${a_n}$ 满足 $a_1 = 3"， "a_(n+1) / n = a_n / (n+1) + 1 / (n(n+1))$.
  + 证明：${n a_n}$ 为等差数列；
  + 设 $f(x) = a_1x + a_2x^2 + dots.c + a_m x^m，求 f'(-2)$.
]

......
```

## Changelog
### 0 . 3 . 2
+ ⚠️ 修改字体，`roman` 重命名为 `roman-font`， 并调整 𝑗𝑓𝑧𝜋∅±/ 的字体为 `STIX Two Math` ，修复 𝑗𝑓 加绝对值后，左侧绝对值的线被遮挡的问题
+ 修复 `tag` 方法，当 `par-justify` 的值设置为 true 时，对不齐的问题
+ 修改 `setup` 的参数 `par-justify` 的默认值为 true
+ 修改 `question` 方法的参数 `points-prefix` 默认值

### 0 . 3 . 1
+ 修复题号重置后，自动生成的引用标签重复出现的问题 （[#7](https://github.com/gbchu/ezexam/issues/7)）
+ 重新为 `chapter` 添加重置题号，小节计数器操作，防止未引入 `title` 方法造成引用的标签错误 （[#7](https://github.com/gbchu/ezexam/issues/7)）
+ 修复 `question` 方法当值为空时，报错信息不正确的问题
+ 修复水印不能调整字体的问题
+ 修复 `subject` 方法传入数字报错的问题
+ 调整引用标签的显示效果，保持和引用显示一致，并在 `question` 方法中，新增参数 `show-ref-prefix` ，该参数设置引用标签时是否显示前缀
+ `title` 方法新增参数 `spacing` ，该参数设置标题文字间的间距
+ 精简 `solution` 方法边框参数，合并为 `border-stroke`
+ 废弃 `scoring-box` 方法，将其与 `score-box` 方法合并，并为其添加参数 `show-rater`
+ 优化目录显示效果

### 0 . 3 . 0
+ `question` 方法，添加新特性，该特性可以让题目被引用，默认生成的 label 为当前章节-题号的形式（[#5](https://github.com/gbchu/ezexam/issues/5)）
  + 新增参数 `ref-on` ，该参数设置是否开启自动生成可被引用的 label
  + 新增参数 `supplement` ，该参数设置引用的前缀
+ `setup` 方法
  + 新增参数 `ref-color` ，该参数设置引用的颜色
  + 新增参数 `list-marker` ，该参数设置列表前标记样式
  + 新增参数 `list-spacing` ，该参数设置列表项之间的间距
  + 新增参数 `list-indent` ，该参数设置列表项的缩进
  + 新增参数 `seal-line-scope` ，该参数设置弥封线的作用域
+ 导出章节，标题，题号计数器
+ 添加对问题题干以行间公式开头时的处理
+ 修复 `EXAM` 下，不显示答案时，目录页显示弥封线的 bug
+ 修复从 0.2.8 开始更换字体导致的下划线错乱的 bug （[#6](https://github.com/gbchu/ezexam/issues/6)）
+ 修复行间公式上下间距过大的问题 （[#6](https://github.com/gbchu/ezexam/issues/6)）
+ 修复在 `question` 方法中，手动换行时，新的行和第一行对不齐的 bug （[#6](https://github.com/gbchu/ezexam/issues/6)）
+ 修复平行线在左侧为数字时，数字和平行线间没有间距的 bug
+ 修复 pi 在罗马字体下显示不正确的 bug 及其左侧为数字时，数字和 pi 之间有间距的 bug
+ 优化页码实现方法

### 0 . 2 . 9
+ 修复 `cover` 方法，手动添加日期时不显示的 bug
+ 修复 `solution` 方法，设置 `inset` 时，如果没有设置左右边距，导致左右边距失效的 bug
+ 修改解析模式实现方式，新增 `solution-block` 方法
+ 修改 `draft` 方法的参数 `dash` 名为 `line-type`
+ 修改 `fillin` 方法的参数 `len` 的默认值为 27.5pt
+ 修改 `title` 方法的参数 `weight` 在 EXAM 模式下的默认值为 400
+ 新增 `page-restart` 方法，该方法可以设置新的章节从指定页码开始
+ `setup` 方法
  + 新增参数 `seal-line-decoration` ，该参数可以为弥封线添加额外的装饰
  + 新增参数 `par-justify`
  + 为参数 `page-align` 新增可选值 `odd-r-even-l`
+ 删除 `tag` 方法的参数 `x` ，并调整其参数 `prefix` 的默认值
+ 优化水印，分割线，弥封线的实现，提高性能

### 0 . 2 . 8
+ 更改 `question` 和 `solution` 方法的核心实现，彻底解决有较高的公式时，题号和题干对不齐的问题。删除这两个方法的 `padding-top` 和 `padding-bottom` 参数；`question` 方法新增参数 `hanging-indent` 并将参数 `body-indent` 修改为 `first-line-indent`
+ 修复以字符《 、【 、（ 开头的题目或选项和标签间的距离过大的问题
+ 优化 `choice` 方法
+ 优化 `text-figure` 方法，删除 `align` 参数
+ 修复 `draft` 未引入 `title` 方法的引起的报错
+ `tag` 方法新增 `weight` 和 `x` 参数
+ 修复 `fillin` 方法有时不显示占位符的 bug
+ 将默认字体修改为 `roman` ，并添加 `TeX Gyre Termes` 字体，修复在线使用 `roman` 字体时，缺少 `Times New Roman` 字体造成的标题西文字体未正确设置的问题
+ 修改 `title` 方法的 `bottom` 参数和`subject` 方法的 `top` 参数的默认值为 0pt
+ `setup` 方法新增参数 `resume` ，该参数可以在同一个文档中重置题号（[#2](https://github.com/gbchu/ezexam/issues/2)）
+ 废弃 `answer` 方法和 `multi` 常量

### 0 . 2 . 7
+ 优化目录的显示效果
+ 优化 `fillin` 方法；修改其参数 `len` 的默认值为 1.5cm。修复当指定长度时，某些值会导致第一行线换行的 bug
+ 调整黑体的字体顺序
+ 修复以数学公式开头的选项，选项和 label 间会增加 .25em 的间距

### 0 . 2 . 6
+ 修复 `fillin` 方法在页面分栏时，不能正确换行的 bug

### 0 . 2 . 5
+ 废弃 `color-box` 方法 ；新增 `tag` 方法替代
+ 重构 `multi`
+ 将 `ROMAN` 修改为 `roman`
+ 优化字体，去掉 `noto serif sc` ；黑体新增 `Heiti SC` ，修复 Mac 用户本地使用时，黑体异常的 bug
+ 优化 `paren` 方法
+ 优化 `text-figure` 方法；修复当图文在新的一页最上面且文本较少时，图表显示不全的 bug ；修复当在一页的最后部分时，有较少部分文本留在当前页，图表也停留在当前页的 bug ，该 bug 使得图表遮挡前面的内容；添加参数 `align`
+ 优化 `fillin` 方法，修复多行线时，线之间的间隔不等的 bug
+ 废弃 `underdot` 方法；使用新的方法实现中文着重号

### 0 . 2 . 4
+ 优化 `choices` 方法；新增参数 `label-position` ； 该参数可在选项为图表时，修改标签的位置。默认在左侧；将参数 `body-indent` 名修改为 `sapcing` ；更加符合语境
+ 优化 `question` 方法，修复题号偏移的 bug
+ 修复修改 `setup` 方法的 `paper` 参数时，只修改部分值报错的 bug
+ 修复在 Typst 的最新版 0.14.0 中数学字体报警告问题

### 0 . 2 . 3
+ 为 `solution` 和 `question` 方法添加 `line-height` 参数；方便修改内容的行间距
+ 优化 `fillin` 方法
+ 修改 `question` 方法在 `HANDOUTS` 模式下的题号样式
+ 修复 `solution` 在 Typst 的最新版 0.14.0 中题号显示的 bug
+ 优化 `paren` 方法，默认填写英文不再大写

### 0 . 2 . 2
+ 调整正文默认字体，由原来的 `Source Han Serif` 修改为 `Noto Serif SC` 、 `Noto Serif CJK SC` （二者效果一样，主要是后者压缩后更小，方便上传网盘进行安装）。黑体添加 `Noto Sans SC` 和 `Noto Sans CJK SC` ；修复在 typst app 中应用模板时，字体显示的问题
+ 添加常量 `ROMAN` ，方便修改字体为新罗马风格的字体，更加符合常见的试卷排版格式
+ 调整代码逻辑，使得在字体调整时，其它所有西文字体统一进行修改
+ 精简 `setup` 方法的参数，删除 `font-math` ；使用 `font` 参数即可完成正文字体和西文字体的设置
+ 调整 π 在罗马字体下显示的样式
+ 修改平行符号为倾斜
+ 修复 `choices` 某个选项有多行时，后续行的缩进和第一行不一致的bug
+ 重写 `fillin` 方法， 实现根据长度生成空线，并根据长度自动换行
+ 修复 `subject` 方法以字符串传入时的bug
+ 优化题号和题干之间的间距

### 0 . 2 . 1
+ 修复试卷模式下，生成 pdf 后的书签会显示题目大标题的问题，确保只显示章节
+ 西文字体新增 Times New Roman 字体风格；前提是安装了 STIX 2 系列字体。如未安装则默认使用 New Computer Modern Math
+ 优化代码

### 0 . 2 . 0
+ 添加 `cover` 方法；该方法可以生成一个封面
+ 添加 `underdot` 方法；在一些场景下，可以为文本添加着重号

### 0 . 1 . 9
+ 优化 `text-figure` 方法；考虑到文本内容较多，为了书写方便，将参数 `text` 修改为位置参数；新增参数 `figure` 、`style` 、`gap`
+ 优化 `question` 方法；修复当一个文档中组多套试卷时，会报警告的问题
+ 优化 `title` 、`score-box` 、`scoring-box` 方法
+ 优化代码

### 0 . 1 . 8
+ 为 `mode`  添加新值 `SOLUTION`，当答案解析独立于试题存在时，使用此值可快速统一格式
+ 优化 `choices` 方法；将其参数 `column` 更名为 `columns`，做到和官方的 `columns` 参数一致
+ 废弃 `inline-square` 方法，推荐使用内置的 `table` 方法
+ 修复 `color-box` 方法报错的 bug
+ 优化 `secret` 、`zh-arabic` 方法
+ 优化 `question` 的编号实现方式；修改 `setup` 方法的参数 `enum-numbering` 的默认值为 `（1.i.a）`
+ 优化 `notice` 方法；新增参数 `indent` 、`hanging-indent`

### 0 . 1 . 7
+ 优化代码，确保 `heading-size` 只修改一级标题；并将其更名为 `h1-size`
+ 为 `title` 方法新增参数 `color`
+ 修复 `solution` 方法，当启用 `title` 时，如果解析内容过多，一页放不下，标题会跑到下一页的 bug；并将其参数 `above` 更名为 `top`；参数 `below` 更名为 `bottom`；统一参数名；添加参数 `padding-top`、`padding-bottom`
+ 去除 `question` 方法参数 `line-height`；该参数会影响题干之间的距离；该参数原本用于设置题目内容的行高，当题目中的公式比较高时，题号和题目内容会错位，这时可以通过该参数来微调。但是会造成内容每一行与行之间的间隔变大。可参考新增的参数 `padding-top`、`padding-bottom` 代替
+ 修复 `choices` 方法，调整其上下外边距导致选项之间的距离会跟着影响的 bug

### 0 . 1 . 6
+ 修复有序列表,内容带有 `box` 时，编号和内容对不齐的 bug
+ 新增化学方程式的单线桥、双线桥的支持；原子、离子结构示意图的支持。使用详情查看 [`化学相关`](https://ezexam.pages.dev/reference/chem)

### 0 . 1 . 5
+ 修复水印被图片遮挡的 bug

### 0 . 1 . 4
+ 将 `LECTURE` 修改为 `HANDOUTS`，更加符合语义
+ 将 `explain` 方法名修改为 `solution`，更加符合语义
+ 修复当修改弥封线类型时，试卷最后一页没有更改的 bug
+ 添加水印功能，`setup` 方法新增参数 `watermark`，`watermark-size`，`watermark-color`，`watermark-font`，`watermark-rotate`

### 0 . 1 . 3
+ 优化 `choices` 方法
+ 将 `question` 方法的参数名 `points-separate-par` 修改为 `points-separate`
+ 增加英文完型填空、7选5题型的支持，让 `paren` 和 `fillin` 方法可以使用题号作为占位符。（[#1](https://github.com/gbchu/ezexam/issues/1)）使用详情查看 [`paren`](https://ezexam.pages.dev/reference/paren) 和 [`fillin`](https://ezexam.pages.dev/reference/fillin) 方法
+ `setup` 方法新增参数 `heading-numbering`，`heading-hanging-indent`，`enum-spacing`，`enum-indent` 提供更多自定义设置
+ 修复 `question` 个数超过9个时，内容对不齐的问题

### 0 . 1 . 2
+ 将 `secret` 修改为方法，可以自定义显示内容
+ 优化 `choices` 方法，当选项过长时，选项从第二行开始进行缩进。修复选项中既有文字又有图表时，标签和内容对不齐的问题
+ 将 `question` 方法的参数 `with-heading-label` 的默认值修改为 `false`
+ `explain` 方法新增参数 `show-number` 、修改参数 `title` 的默认值为 `none`，默认不显示
+ `setup` 方法新增参数 `enum-numbering`

### 0 . 1 . 1
+ 修复 `choices` 方法中，若选项为图片时，设置宽度为百分比时，图片宽度无效的问题

### 0 . 1 . 0
+ 初版发布
